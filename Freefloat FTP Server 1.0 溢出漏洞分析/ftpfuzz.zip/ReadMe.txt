			Infigo FTPStress Fuzzer v1.0
			============================


First of all, thank you for downloading this software, we hope that you will
find it useful and enjoy it.

Infigo FTPStress Fuzzer is free software, released under Software Product 
License (see License.txt for details)


1) Introduction
---------------


Fuzzing is a special process used for discovering security vulnerabilities in
software products. The process is performed by sending specially crafted data
of various types and sizes to the application�s standard input, trying to
reach incorrect processing state which will reveal the vulnerability. During
the fuzzing process, target application is usually monitored with additional
tools (e.g. debuggers) which can be helpful for analysis of anomalies and
application�s unexpected behaviour.

There is a variety of fuzzing tools, depending on the nature of the target
application. Generic fuzzing tools could be used for analysis of different
protocols and applications, while specific are designed for the particular
protocols (SMTP, HTTP, POP3, FTP etc.).

Infigo FTPStress Fuzzer is a specific fuzzer for finding vulnerabilities in
FTP server products. Although it is a simple tool, it proved its efficiency
by the number of vulnerabilities discovered in different FTP server software
tested with this tool.
The parameters used for the fuzzing process are highly configurable. User can
precisely define which FTP commands will be fuzzed along with the size and
type of the fuzzing data.


2) Installation
-------------


Unzip the package into the directory of your choice and run ftpfuzz.exe,
Infigo  FTPStress Fuzzer starts immediately.


3) Configuration
----------------


3.1) Setting up fuzz commands
-----------------------------


"FTP commands" window shows all available FTP commands. Checkbox by each
command checks the command for execution. Drop down menu enables quick
checking or clearing specific groups of commands:
	- Default - selects default ftp commands,
	- All commands - selects all commands,
	- Basic commands (RFC 959) - selects commands defined in RFC 959,
	- Deselect all - clears all checkboxes,
	- File transfer commands - selects commands used for file transfer,
	- File commands - selects commands used for file handling,
	- SITE commands - selects only SITE commands.

By pressing the "Discover" button it is possible to automatically select only
commands that target FTP server supports. By pressing the �Discover� button
Infigo FTP Fuzzer sends "Help" command to the target FTP server and upon
server�s response checks only supported commands.

By highlighting one of the FTP commands, it becomes available in the upper
section of the main window. This enables the user to change the command by
entering a new value and pressing "Update Change". With this option the
existing command is replaced by new one.
In this section it is also possible to enter argument which will be sent to
the FTP server. Checkbox "Fuzz this FTP command" checks the command for
fuzzing. In this case, user provided argument will be ignored, and instead,
selected fuzzing data strings will be used as arguments. Fuzzing strings are
described in section 3.2.


3.2) Fuzzing parameters
-----------------------


Fuzzing parameters are configured either by selecting "Config" option from
the toolbar, or by pressing "Config" button. This opens a new window which
offers three tabs.

==[ Fuzzing data

This tab lists data strings which will be used for fuzzing. It is possible to
change the string by selecting it and entering new value. "Update Change"
button must be pressed for change to take an effect.

==[ Fuzzing sizes

This tab lists available lengths of the strings that will be sent to the target 
FTP server. It is possible to change them the same way as described in "Fuzzing
data" tab.

==[ Fuzzing options

This tab allows user to determine whether the commands will be fuzzed one at
the time (with all selected data and sizes), or will the selected commands be
executed consecutively with the same fuzzing data and size before changing
the argument.

"Retrieve files (data connections) from FTP server" option enables saving
data retrieved from the target FTP server. Local data port must be defined so
Infigo FTPStress Fuzzer can bind to it. Retrieved data can be revised by
Selecting "Data" button. By default, local data port is set to 31339 what can
be changed manually.


4) Using Infigo FTPStress Fuzzer
--------------------------------


Using Infigo FTPStress Fuzzer is straightforward and simple.


4.1) Starting the fuzzing process
-------------


Before starting the Fuzzer, "Connection" section of the main window must be 
filled. Host IP address is empty by default and should be entered. By
default, target server�s FTP port is set to 21, while local data port is set
to 31339. This can be changed as necessary.
Timeout value defines how long the Fuzzer waits for the response from the
target FTP server. By default, this value is set to 12 seconds. This value
should be carefully selected since it can seriously affect the results.
The fuzzing process is started by pressing "Start" button. The process can be
paused or stopped before completion by pressing �Pause� or �Stop� buttons.


4.2) Output
-----------


Sent and received data is being displayed in the real time in the Fuzzer�s
central frame. The output is highlited in three colors which represent
different actions:
	- Black - requests sent by the Fuzzer,
	- Blue - answers received from the FTP server,
	- Red - indicates the FTP server being down.

"Data" button opens new window which displays retrieved data from the FTP
server. Retrieved data is available only if "Retrieve files (data
connections) from FTP server" option is enabled.

The progress bar in the bottom of the main window displays the progress and the 
command, data string and size currently being fuzzed.


5) Contact
----------


All bug reports and requests for new features can be sent to:
infocus@infigo.hr

Infigo FTPStress Fuzzer URL:
http://www.infigo.hr/in_focus/tools