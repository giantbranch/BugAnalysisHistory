mona
====

Corelan Repository for mona.py


Installation instructions
-------------------------

### Immunity Debugger
Simply drop mona.py into the 'PyCommands' folder (inside the Immunity Debugger application folder).

### WinDBG
See https://github.com/corelan/windbglib
